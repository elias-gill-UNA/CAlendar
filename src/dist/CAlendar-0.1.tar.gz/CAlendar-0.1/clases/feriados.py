class Feriados:
    def __init__(self, descripcion, fecha):
        self.feriado = descripcion
        self.fecha = fecha
