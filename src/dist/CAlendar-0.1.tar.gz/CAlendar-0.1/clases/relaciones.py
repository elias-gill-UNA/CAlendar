class relacion:
    def __init__(self,identificador,identificadorAntes,identificadorDespues):
        self.identificador=identificador # numerico
        self.identificadorAntes=identificadorAntes # numerico
        self.identificadorDespues=identificadorDespues # numerico
