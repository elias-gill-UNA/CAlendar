from tkinter import *
from navbar import *

root = Tk()

Inicializar(root)

root.mainloop()