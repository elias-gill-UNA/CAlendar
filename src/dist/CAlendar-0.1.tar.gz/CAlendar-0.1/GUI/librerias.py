import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkcalendar import *
from src.clases import proyecto as Pr
from src.clases import actividades as Ac
from crear_edit_borrarActividades import *
import sqlite3
from src.utilidades.informes import diagrama_de_gant
